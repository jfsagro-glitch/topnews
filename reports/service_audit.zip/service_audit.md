ЖУРБОТ — Отчет об аудите услуг

1. Резюме

Общий статус: Критический
Количество ошибок: 7
Количество предупреждений: 71

2. Статус услуг

| Сервис | Статус | Время ответа | Ошибки |
|---|---|---|---|
| API backend /health | UNKNOWN | 3084ms | n/a |
| API backend /ready | UNKNOWN | 2816ms | n/a |
| Mgmt API /mgmt/collection/stop | UNKNOWN | 820ms | All connection attempts failed |
| Redis | UNKNOWN | - | REDIS_URL not set |
| Database db/news.db | OK | - | - |
| Access DB db/access.db | OK | - | - |

3. Статус ботов

| Бот | Telegram OK | Обработчики OK | ИИ OK | Примечания |
|---|---|---|---|---|
| prod | UNKNOWN | OK | UNKNOWN | token not set |
| sandbox | UNKNOWN | OK | UNKNOWN | token not set |
| active | UNKNOWN | OK | UNKNOWN | token not set |

4. Проверка ИИ

| Поставщик | Статус | Средний ответ | Тайм-аут |
|---|---|---|---|
| DeepSeek | UNKNOWN | 1995ms | 10s |

5. Целостность базы данных

| Проверка | Статус | Примечания |
|---|---|---|
| Required tables | OK | present |
| Indexes | OK | present |
| Orphan records | OK | user_source_settings=0, user_news_selections=0, ai_summaries=0 |

6. Анализ

| Источник | Статус | Последняя загрузка | Ошибки |
|---|---|---|---|
| https://ria.ru/world/ | OK | - | None |
| https://lenta.ru/tags/geo/ | OK | - | None |
| https://tass.ru/rss/index.xml | OK | - | None |
| https://www.gazeta.ru/news/ | OK | - | None |
| https://rg.ru/world/ | OK | - | None |
| https://www.rbc.ru/v10/static/rss/rbc_news.rss | OK | - | None |
| https://russian.rt.com/rss/ | ERROR | - |  |
| https://www.interfax.ru/world/ | OK | - | None |
| https://iz.ru/xml/rss/all.xml | OK | - | None |
| https://ren.tv/news | OK | - | None |
| https://ria.ru/ | OK | - | None |
| https://lenta.ru/ | OK | - | None |
| https://www.gazeta.ru/news/ | OK | - | None |
| https://tass.ru/rss/v2.xml | OK | - | None |
| https://rg.ru/ | OK | - | None |
| https://ren.tv/news | OK | - | None |
| https://iz.ru/xml/rss/all.xml | OK | - | None |
| https://russian.rt.com/rss/ | ERROR | - |  |
| https://www.rbc.ru/v10/static/rss/rbc_news.rss | OK | - | None |
| https://rss.kommersant.ru/K40/ | ERROR | - | [Errno 11001] getaddrinfo failed |
| https://www.interfax.ru/rss | OK | - | None |
| https://t.me/mash | OK | - | None |
| https://t.me/bazabazon | OK | - | None |
| https://t.me/shot_shot | OK | - | None |
| https://t.me/mod_russia | OK | - | None |
| https://ria.ru/location_Moskovskaja_oblast/ | OK | - | None |
| https://lenta.ru/tags/geo/moskovskaya-oblast/ | OK | - | None |
| https://iz.ru/tag/moskovskaia-oblast | ERROR | - |  |
| https://tass.ru/moskovskaya-oblast | OK | - | None |
| https://rg.ru/region/cfo/podmoskovie | OK | - | None |
| https://360.ru/rubriki/mosobl/ | OK | - | None |
| https://mosreg.ru/sobytiya/novosti | OK | - | None |
| https://riamo.ru/tag/podmoskove/ | OK | - | None |
| https://mosregtoday.ru/news/ | OK | - | None |
| https://www.interfax-russia.ru/center/novosti-podmoskovya | ERROR | - |  |
| https://regions.ru/news | ERROR | - |  |
| https://news.yahoo.com/rss/ | ERROR | - |  |
| https://news.yahoo.com/rss/world | ERROR | - |  |
| https://naked-science.ru/ | ERROR | - |  |
| https://new-science.ru/category/news/ | OK | - | None |
| https://forklog.com/news | ERROR | - |  |
| https://t.me/ruptlyalert | OK | - | None |
| https://t.me/tass_agency | OK | - | None |
| https://t.me/rian_ru | ERROR | - | None |
| https://t.me/mod_russia | OK | - | None |

7. Безопасность

| Проверка | Статус |
|---|---|
| Webhook secret configured | OK |
| Webhook base URL set | OK |
| Admin-only sandbox policy | UNKNOWN |

8. Производительность

| Метрика | Значение |
|---|---|
| Memory usage | UNKNOWN |
| CPU spikes (30d) | UNKNOWN |
| Slow queries > 1s | UNKNOWN |
| Slow query log | UNKNOWN |

9. Критические вопросы

- КРИТИЧЕСКИЙ: Active BOT_TOKEN missing or placeholder

Сформировано: 2026-02-13T12:08:11.429467Z