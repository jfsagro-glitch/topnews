# 🚀 TopNews Bot - Railway Deployment Guide

## 📌 Краткое резюме

**TopNews Bot** - это асинхронный Telegram-бот для агрегации новостей из 21+ источников.

**Развернут на:** Railway (https://railway.app)  
**Репозиторий:** https://github.com/jfsagro-glitch/topnews

---

## ⚡ Что изменилось для Railway

Проект полностью адаптирован для развертывания на Railway:

### ✨ Новые файлы:

| Файл | Назначение |
|------|-----------|
| `Procfile` | Определяет как запустить бота на Railway |
| `railway.json` | Конфигурация Railway (restart policy, volumes) |
| `config/railway_config.py` | Поддержка переменных окружения Railway |
| `init_db.py` | Инициализация БД при запуске |
| `RAILWAY_QUICKSTART.md` | Быстрый старт на Railway |
| `RAILWAY_DEPLOY.md` | Подробная документация |
| `check_railway_ready.py` | Проверка готовности к деплою |

### 🔄 Обновленные файлы:

- `main.py` - теперь поддерживает Railway конфиг
- `config/config.py` - без изменений, работает локально
- `requirements.txt` - готов для Railway

---

## 🚀 Быстрый старт

### 1. Подготовка переменных окружения

Вам понадобятся:

**TELEGRAM_TOKEN** - токен от @BotFather
```
Пример: 123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11
```

**TELEGRAM_CHANNEL_ID** - ID вашего канала
```
Пример: -1001234567890
```

[Подробно как их получить](RAILWAY_QUICKSTART.md)

### 2. Развертывание на Railway

```bash
# 1. Убедитесь что код в GitHub
git push origin main

# 2. Перейдите на https://railway.app
# 3. Создайте новый проект
# 4. Выберите "Deploy from GitHub"
# 5. Выберите jfsagro-glitch/topnews
# 6. Установите переменные окружения
# 7. Нажмите Deploy

# ✅ Готово! Бот запустится автоматически
```

### 3. Проверка статуса

```
Telegram → отправьте боту /help
```

Должны увидеть:
```
/sync - Запустить сбор новостей сейчас
/status - Статистика
/pause - Приостановить сбор
/resume - Возобновить сбор
```

---

## 📊 Архитектура

```
┌─────────────────────────────────────┐
│         Railway Platform            │
├─────────────────────────────────────┤
│  main.py (Procfile entry point)     │
│         ↓                           │
│    NewsBot (async loop)             │
│    ├─ collect_and_publish()         │
│    └─ run_periodic_collection()     │
│         ↓                           │
│  ┌──────────────────────┐           │
│  │ SourceCollector      │           │
│  ├─ RSSParser          │ (parallel │
│  ├─ HTMLParser         │  async)   │
│  ├─ TelegramSource     │           │
│  └─ AuthSource        │           │
│         ↓              │           │
│  ┌──────────────────────┐           │
│  │ TextCleaner         │           │
│  │ format_telegram_msg │           │
│  └──────────────────────┘           │
│         ↓                           │
│  ┌──────────────────────┐           │
│  │ NewsDatabase        │ (/persist │
│  │ (SQLite)            │  volume)  │
│  └──────────────────────┘           │
│         ↓                           │
│  Telegram Channel                   │
└─────────────────────────────────────┘
```

---

## 🔧 Переменные окружения

### Обязательные:

```env
TELEGRAM_TOKEN=123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11
TELEGRAM_CHANNEL_ID=-1001234567890
```

### Опциональные:

```env
# Интервал проверки источников (секунды, по умолч. 120)
CHECK_INTERVAL_SECONDS=120

# Timeout для запросов (секунды, по умолч. 30)
TIMEOUT_SECONDS=30

# Уровень логирования (DEBUG/INFO/WARNING/ERROR, по умолч. INFO)
LOG_LEVEL=INFO

# Путь к БД (по умолч. db/news.db, для Railway используйте /persist/news.db)
DATABASE_PATH=/persist/news.db

# Прокси (если требуется)
USE_PROXY=False
PROXY_URL=http://proxy.example.com:8080

# Закрытые источники (если требуется авторизация)
CLOSED_SOURCE_LOGIN=username
CLOSED_SOURCE_PASSWORD=password
```

---

## 💾 Сохранение данных (Persistence)

По умолчанию БД хранится в памяти приложения.

### Для сохранения БД между перезагрузками:

1. В Railway Dashboard → Volumes
2. Добавьте volume: `/persist`
3. В Variables установите: `DATABASE_PATH=/persist/news.db`

Теперь БД будет сохраняться на диске Railway.

---

## 🔍 Проверка готовности

Перед первым деплоем запустите проверку локально:

```bash
python check_railway_ready.py
```

Должны увидеть:
```
✅ Procfile (Запуск приложения)
✅ railway.json (Конфигурация Railway)
✅ requirements.txt (Зависимости Python)
✅ ... все остальные файлы
```

---

## 📊 Мониторинг

### Логи в Railway:

1. Railway Dashboard → Deployments
2. Нажмите на последний Deploy
3. Посмотрите Logs
4. Должны видеть:

```
✅ Bot started successfully
✅ Database ready
✅ Periodic collection started
```

### Статистика:

```
/status - показывает:
- Всего новостей опубликовано
- Последние источники
- Время сбора
```

---

## 🆘 Troubleshooting

### ❌ Ошибка: "ModuleNotFoundError"

**Решение:** Railway не установил зависимости
- Проверьте что `requirements.txt` в корне репозитория
- Пересоздайте deployment

### ❌ Бот не публикует новости

**Проверьте:**
1. TELEGRAM_TOKEN и CHANNEL_ID в Variables
2. Логи на предмет ошибок
3. Бот добавлен в канал администратором

### ❌ БД теряется при перезагрузке

**Решение:** Добавьте Volume (/persist)

### ❌ Медленный сбор новостей

**Увеличьте интервал:**
```env
CHECK_INTERVAL_SECONDS=180  # 3 минуты вместо 2
TIMEOUT_SECONDS=60         # 60 сек вместо 30
```

---

## 📁 Структура проекта

```
topnews/
├── config/
│   ├── config.py                 # Основная конфигурация
│   ├── railway_config.py         # Railway конфигурация
│   └── __init__.py
├── db/
│   ├── database.py               # SQLite database
│   └── __init__.py
├── parsers/
│   ├── rss_parser.py             # RSS parser (feedparser)
│   ├── html_parser.py            # HTML parser (BeautifulSoup)
│   └── __init__.py
├── sources/
│   ├── source_collector.py       # Координатор источников
│   ├── telegram_source.py        # Telegram источник
│   ├── auth_source.py            # Авторизованные источники
│   └── __init__.py
├── utils/
│   ├── logger.py                 # Логирование
│   ├── text_cleaner.py           # Обработка текста
│   └── __init__.py
├── logs/                         # Логи (создается при запуске)
├── bot.py                        # Главный bot класс
├── main.py                       # Entry point
├── init_db.py                    # Инициализация БД
├── requirements.txt              # Зависимости
├── Procfile                      # Railway entry point
├── railway.json                  # Railway конфиг
├── .env.example                  # Пример переменных
├── .gitignore                    # Git исключения
└── RAILWAY_QUICKSTART.md         # Railway гайд
```

---

## 🚀 Автоматические обновления

После первоначального развертывания:

```bash
# 1. Делайте изменения локально
echo "новые источники" >> sources.txt

# 2. Пушьте в GitHub
git add .
git commit -m "Add new sources"
git push origin main

# 3. Railway автоматически обновит (1-2 мин)
# 4. Бот перезагрузится с новым кодом
```

---

## 💰 Стоимость Railway

- **$5 кредит в месяц** (free tier)
- Для простого бота этого более чем достаточно
- Средний расход: **$1-3 в месяц**

---

## 📞 Полезные ссылки

- **Railway Docs:** https://docs.railway.app
- **Railway Discord:** https://railway.app/discord
- **Telegram Bot API:** https://core.telegram.org/bots
- **@BotFather:** https://t.me/BotFather
- **GitHub Repo:** https://github.com/jfsagro-glitch/topnews

---

## 📝 Полный гайд по Railway

Для более подробной информации смотрите:
- [RAILWAY_QUICKSTART.md](RAILWAY_QUICKSTART.md) - быстрый старт
- [RAILWAY_DEPLOY.md](RAILWAY_DEPLOY.md) - полная документация

---

## ✅ Чек-лист для развертывания

- [ ] Создан Telegram бот (@BotFather)
- [ ] Получен TELEGRAM_TOKEN
- [ ] Создан приватный Telegram канал
- [ ] Получен TELEGRAM_CHANNEL_ID
- [ ] Код в GitHub репозитории
- [ ] Создан проект на Railway
- [ ] Установлены переменные окружения
- [ ] Deployment в статусе "Success"
- [ ] Бот отвечает на /help
- [ ] Новости появляются в канале

---

**Готово! Ваш TopNews Bot в облаке на Railway! 🎉**
