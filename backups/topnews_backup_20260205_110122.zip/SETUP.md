# Руководство по запуску TopNews Bot

## 🚀 Быстрый старт (5 минут)

### Шаг 1: Получение Telegram Token

1. Откройте Telegram и найдите бота **@BotFather**
2. Отправьте команду `/newbot`
3. Следуйте инструкциям BotFather
4. Скопируйте полученный токен (выглядит так: `123456789:ABCDefGHIjklmnoPQRstuvWXYZ`)

### Шаг 2: Создание канала

1. Создайте новый приватный или публичный канал
2. Добавьте созданного бота в канал
3. Сделайте бота администратором с правом на размещение сообщений
4. Получите Channel ID:
   - Добавьте @userinfobot в канал
   - Отправьте `/start`
   - Отправьте `/info`
   - Скопируйте ID канала (отрицательное число)

### Шаг 3: Настройка .env файла

1. Скопируйте `.env.example` в `.env`:
```bash
copy .env.example .env
```

2. Отредактируйте `.env` и заполните значения:
```env
TELEGRAM_TOKEN=123456789:ABCDefGHIjklmnoPQRstuvWXYZ
TELEGRAM_CHANNEL_ID=-1001234567890
LOG_LEVEL=INFO
```

### Шаг 4: Установка зависимостей

```bash
pip install -r requirements.txt
```

### Шаг 5: Запуск бота

```bash
python main.py
```

Если все правильно настроено, вы должны увидеть в логах:
```
2024-01-31 12:00:00 - root - INFO - ==================================================
2024-01-31 12:00:00 - root - INFO - Telegram News Aggregation Bot Starting
2024-01-31 12:00:00 - root - INFO - ==================================================
2024-01-31 12:00:00 - root - INFO - Bot started successfully
```

## 📱 Тестирование

1. Отправьте боту команду `/help` - должны увидеть список команд
2. Отправьте `/sync` - должна начаться сборка новостей
3. Проверьте канал - новости должны начать появляться

## 🔧 Дополнительная конфигурация

### Интервал проверки новостей

В файле [config/config.py](config/config.py) измените:
```python
CHECK_INTERVAL_SECONDS = 120  # Текущее значение: 2 минуты
# Измените на нужное (в секундах)
CHECK_INTERVAL_SECONDS = 300  # Например: 5 минут
```

### Добавление новых источников

1. Откройте [config/config.py](config/config.py)
2. Найдите раздел `SOURCES_CONFIG`
3. Добавьте новый источник в нужную категорию:
```python
'SOURCES_CONFIG = {
    'russia': {
        'sources': [
            'https://your-new-source.ru/rss',  # Для RSS
            'https://your-new-source.ru/news', # Для HTML
        ]
    }
}'
```

### Использование прокси

Отредактируйте `.env`:
```env
USE_PROXY=True
PROXY_URL=http://proxy.example.com:8080
```

## 📊 Мониторинг логов

Логи сохраняются в `logs/bot.log`. Просмотрите их:

```bash
# Windows (PowerShell)
Get-Content logs\bot.log -Tail 50  # Последние 50 строк

# Linux/Mac
tail -f logs/bot.log  # Реал-тайм просмотр
```

## 🆘 Решение проблем

### "Ошибка: ConnectionError при запуске"
- Проверьте интернет соединение
- Проверьте корректность TELEGRAM_TOKEN в `.env`

### "Bot не публикует новости"
- Проверьте, что бот добавлен в канал как администратор
- Проверьте корректность TELEGRAM_CHANNEL_ID
- Запустите `/sync` и посмотрите логи

### "ModuleNotFoundError: No module named '...'"
- Перейдите в папку проекта
- Запустите `pip install -r requirements.txt` заново

### "Timeout при сборе новостей"
- Это нормально - некоторые источники могут быть медленными
- Бот продолжит работу с доступными источниками
- Посмотрите логи для деталей

## 🛑 Остановка бота

Нажмите `Ctrl+C` в терминале для безопасной остановки.

## 🔄 Автоматический запуск

### Windows (Task Scheduler)

1. Откройте Task Scheduler
2. Создайте новую задачу
3. Установите триггер: "При запуске системы"
4. Действие: запустить программу
   - Program: `C:\Users\YourUsername\TopNews\.venv\Scripts\python.exe`
   - Arguments: `C:\Users\YourUsername\TopNews\main.py`
   - Start in: `C:\Users\YourUsername\TopNews`

### Linux/Mac (Systemd/Launchd)

Создайте systemd сервис (`/etc/systemd/system/topnews.service`):
```ini
[Unit]
Description=TopNews Telegram Bot
After=network.target

[Service]
Type=simple
User=youruser
WorkingDirectory=/path/to/TopNews
ExecStart=/path/to/TopNews/.venv/bin/python /path/to/TopNews/main.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

Затем запустите:
```bash
sudo systemctl enable topnews
sudo systemctl start topnews
```

## 📚 Дополнительные ресурсы

- [python-telegram-bot документация](https://python-telegram-bot.readthedocs.io/)
- [Telegram Bot API](https://core.telegram.org/bots/api)
- [feedparser документация](https://feedparser.readthedocs.io/)
- [BeautifulSoup документация](https://www.crummy.com/software/BeautifulSoup/bs4/doc/)

## 📞 Поддержка

Если что-то не работает:
1. Проверьте логи в `logs/bot.log`
2. Убедитесь, что все зависимости установлены
3. Проверьте конфигурацию в `.env`
4. Попробуйте перезагрузить бота
