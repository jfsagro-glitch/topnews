"""
Railway deployment guide

Развертывание TopNews Bot на Railway за 10 минут
"""

# ШАГИ РАЗВЕРТЫВАНИЯ:

"""
1. ПОДГОТОВКА РЕПОЗИТОРИЯ
   ✅ Проект уже находится на GitHub: https://github.com/jfsagro-glitch/topnews
   ✅ Файл Procfile уже добавлен
   ✅ Файл railway.json уже добавлен
   ✅ requirements.txt содержит все зависимости

2. СОЗДАНИЕ RAILWAY ПРОЕКТА
   - Перейдите на https://railway.app
   - Нажмите "Start a New Project"
   - Выберите "Deploy from GitHub"
   - Авторизуйтесь и выберите репозиторий jfsagro-glitch/topnews
   - Railway автоматически создаст сервис

3. УСТАНОВКА ПЕРЕМЕННЫХ ОКРУЖЕНИЯ
   В Railway Dashboard перейдите в Variables и установите:
   
   TELEGRAM_TOKEN=ваш_токен_от_BotFather
   TELEGRAM_CHANNEL_ID=-1001234567890
   CHECK_INTERVAL_SECONDS=120
   LOG_LEVEL=INFO
   
   Дополнительные (если нужны):
   - CLOSED_SOURCE_LOGIN (для авторизованных источников)
   - CLOSED_SOURCE_PASSWORD
   - USE_PROXY=True / PROXY_URL=...
   - DATABASE_PATH=/persist/news.db (для persistence)

4. НАСТРОЙКА PERSISTENCE (важно!)
   Railway предоставляет volume для сохранения данных:
   - В Railway Dashboard нажмите на сервис
   - Перейдите в "Volumes"
   - Добавьте volume: /persist
   - Установите DATABASE_PATH=/persist/news.db в переменных

5. РАЗВЕРТЫВАНИЕ
   - Railway автоматически развернет при push в GitHub
   - Посмотрите логи в Railway Dashboard → Deploy Logs
   - Бот должен запуститься автоматически

6. МОНИТОРИНГ
   - Проверьте логи: Railway Dashboard → Logs
   - Бот должен показывать "Bot started successfully"
   - Проверьте, что новости публикуются в канал Telegram

ФАЙЛЫ КОНФИГУРАЦИИ:

1. Procfile:
   - Определяет как запустить приложение
   - Railway распознает Python и установит зависимости

2. railway.json:
   - Дополнительная конфигурация для Railway
   - Определяет команду запуска
   - Указывает restart policy

3. config/railway_config.py:
   - Автоматически загружает переменные из Railway
   - Проверяет обязательные переменные
   - Поддерживает .env локально

ПЕРЕМЕННЫЕ ОКРУЖЕНИЯ:

Обязательные:
- TELEGRAM_TOKEN: токен бота от BotFather
- TELEGRAM_CHANNEL_ID: ID канала для публикации

Опциональные:
- CHECK_INTERVAL_SECONDS: интервал проверки (по умолч. 120)
- LOG_LEVEL: уровень логирования (DEBUG/INFO/WARNING/ERROR)
- DATABASE_PATH: путь к БД (по умолч. db/news.db)
- USE_PROXY: использовать прокси (True/False)
- PROXY_URL: URL прокси если USE_PROXY=True
- CLOSED_SOURCE_LOGIN: логин для авторизованных источников
- CLOSED_SOURCE_PASSWORD: пароль

TROUBLESHOOTING:

Проблема: "ModuleNotFoundError: No module named 'telegram'"
Решение: Railway должен установить зависимости из requirements.txt
         Проверьте что requirements.txt находится в корне репозитория

Проблема: Бот не публикует новости
Решение: 
- Проверьте переменные окружения в Railway
- Посмотрите логи на предмет ошибок
- Убедитесь что TELEGRAM_CHANNEL_ID верный

Проблема: БД потеряется при перезагрузке
Решение: Добавьте Volume в Railway и установите DATABASE_PATH=/persist/news.db

Проблема: Бот часто падает
Решение: 
- Увеличьте TIMEOUT_SECONDS в переменных
- Уменьшите CHECK_INTERVAL_SECONDS если источники медленные
- Проверьте логи на ошибки парсинга

БОЛЕЕ ПОДРОБНО:

Получение TELEGRAM_TOKEN:
1. Откройте Telegram и найдите @BotFather
2. Отправьте /newbot
3. Следуйте инструкциям
4. Скопируйте токен

Получение TELEGRAM_CHANNEL_ID:
1. Создайте приватный канал
2. Добавьте бота в канал как администратора
3. Добавьте @userinfobot в канал
4. Отправьте /start
5. Отправьте /info
6. Скопируйте Chat ID (отрицательное число)

АВТОМАТИЧЕСКОЕ РАЗВЕРТЫВАНИЕ:

После первоначальной настройки:
1. Просто пушьте изменения в GitHub
2. Railway автоматически перестроит и переразвернет
3. Логи будут видны в Railway Dashboard

SCALE & MONITORING:

Railway предоставляет:
- Автоматическое масштабирование (платно)
- Мониторинг ресурсов (CPU, Memory)
- Логи в реальном времени
- Интеграция с GitHub для автоматического деплоя

ЦЕНА:

Railway использует pay-as-you-go модель:
- $5 кредит в месяц (free tier)
- Для простого бота этого более чем достаточно
- Примерный расход: $1-2 в месяц

СЛЕДУЮЩИЕ ШАГИ:

1. Убедитесь что у вас есть GitHub аккаунт и репозиторий
2. Зарегистрируйтесь на Railway.app
3. Создайте Telegram бота у @BotFather
4. Создайте Telegram канал
5. Установите переменные окружения в Railway
6. Нажмите Deploy
7. Проверьте логи
8. Готово! 🚀

"""
