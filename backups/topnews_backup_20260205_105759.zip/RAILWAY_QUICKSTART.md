# 🚀 Railway Deployment Quick Start

## Ваш проект готов к развертыванию!

Репозиторий: **https://github.com/jfsagro-glitch/topnews**

---

## ⚡ Быстрый старт (10 минут)

### 1️⃣ На Railway.app (https://railway.app)

1. Нажмите **"New Project"**
2. Выберите **"Deploy from GitHub"**
3. Авторизуйтесь GitHub
4. Выберите репозиторий `jfsagro-glitch/topnews`
5. Нажмите **"Deploy"**

> Railway автоматически распознает `Procfile` и развернет приложение

---

## 🔐 Переменные окружения

После развертывания перейдите в **Variables** и установите:

### ✅ Обязательные:

```env
TELEGRAM_TOKEN=123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11
TELEGRAM_CHANNEL_ID=-1001234567890
```

### ⚙️ Рекомендуемые:

```env
CHECK_INTERVAL_SECONDS=120
LOG_LEVEL=INFO
```

### 🔒 Дополнительные (при необходимости):

```env
USE_PROXY=False
CLOSED_SOURCE_LOGIN=username
CLOSED_SOURCE_PASSWORD=password
```

---

## 📍 Как получить TELEGRAM_TOKEN

1. Откройте Telegram
2. Найдите **@BotFather**
3. Отправьте `/newbot`
4. Следуйте инструкциям
5. Скопируйте токен

```
Example: 123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11
```

---

## 📍 Как получить TELEGRAM_CHANNEL_ID

1. Создайте новый **приватный** канал в Telegram
2. Добавьте **вашего бота** как администратора
3. Отправьте в канал сообщение
4. Добавьте **@userinfobot** в канал
5. Напишите в @userinfobot `/info`
6. Скопируйте **Chat ID** (отрицательное число)

```
Example: -1001234567890
```

---

## 💾 Сохранение БД (Persistence)

По умолчанию БД хранится в памяти и теряется при перезагрузке.

### Для включения persistence:

1. В Railway Dashboard перейдите в **Volumes**
2. Нажмите **"Add Volume"**
3. Установите путь: `/persist`
4. В **Variables** добавьте:

```env
DATABASE_PATH=/persist/news.db
```

> Теперь БД будет сохраняться между перезагрузками

---

## 📊 Статус бота

### Логи:

1. Railway Dashboard → **Deployments**
2. Нажмите на последний Deploy
3. Посмотрите **Logs**

Должно быть:
```
✅ Bot started successfully
✅ Database ready
✅ Periodic collection started
```

### Проверка:

В Telegram:
1. Напишите боту `/help`
2. Должны увидеть список команд
3. Отправьте `/status` - должна быть информация о статистике

---

## 🔄 Автоматические обновления

После первоначальной настройки:

1. Делайте изменения локально
2. Пушьте в GitHub
3. Railway автоматически перестроит и переразвернет
4. Бот перезагрузится с новым кодом

```bash
git add .
git commit -m "Update sources"
git push origin main
```

> Railway обновит примерно через 1-2 минуты

---

## ⚠️ Troubleshooting

### ❌ Ошибка: "ModuleNotFoundError: No module named 'telegram'"

**Решение:** Railway должен установить зависимости из `requirements.txt`
- Проверьте что файл в корне репозитория
- Посмотрите Logs на ошибки при установке

### ❌ Бот не публикует новости

**Проверьте:**
1. TELEGRAM_TOKEN и TELEGRAM_CHANNEL_ID в Variables
2. Логи на предмет ошибок: Railway Dashboard → Logs
3. Бот добавлен в канал администратором

### ❌ БД потеряется при перезагрузке

**Решение:** Добавьте Volume (см. "Сохранение БД")

### ❌ Бот часто падает

**Причины:**
- Медленные источники → увеличьте `TIMEOUT_SECONDS`
- Частые проверки → увеличьте `CHECK_INTERVAL_SECONDS`

```env
TIMEOUT_SECONDS=60
CHECK_INTERVAL_SECONDS=180
```

---

## 💰 Стоимость

Railway используют **pay-as-you-go** модель:

- **$5 кредит в месяц** (free tier)
- Для простого бота этого достаточно
- Средний расход: **$1-3 в месяц**

---

## 📞 Поддержка Railway

- Документация: https://docs.railway.app
- Discord: https://railway.app/discord
- Статус: https://railway.app/status

---

## 🎉 Готово!

Ваш бот должен быть в эфире. 

**Дальнейшие шаги:**
1. ✅ Проверьте, что бот публикует новости
2. ✅ Настройте источники по своему вкусу
3. ✅ Добавьте больше каналов если нужно
4. ✅ Настройте интервал проверки

---

## 📝 Полезные ссылки

- [Telegram Bot API](https://core.telegram.org/bots)
- [Railway Documentation](https://docs.railway.app)
- [GitHub Repository](https://github.com/jfsagro-glitch/topnews)
- [@BotFather](https://t.me/BotFather)

---

**Успехов! 🚀**
