# 🚀 DEPLOYMENT GUIDE (01.02.2026)

## ✅ Статус: ГОТОВО К ДЕПЛОЮ

Проект полностью подготовлен к развёртыванию на Railway.

---

## 📋 Перед деплоем

1. **Проверка:**
   - ✅ Все коммиты запушены в GitHub (`main` branch)
   - ✅ Dockerfile готов
   - ✅ Procfile настроен
   - ✅ requirements.txt актуален
   - ✅ Переменные окружения определены

2. **Необходимые переменные окружения (установить в Railway Dashboard):**
   ```
   TELEGRAM_TOKEN=<ваш_токен_от_@BotFather>
   TELEGRAM_CHANNEL_ID=<ID_целевого_канала>
   CHECK_INTERVAL_SECONDS=120  (опционально)
   LOG_LEVEL=INFO  (опционально)
   ```

3. **Git статус:**
   ```
   Последний коммит: 50e807d (Stage 1: Refactor HTTP client...)
   Ветка: main
   Статус: всё запушено
   ```

---

## 🎯 Что нового в текущем деплое (Stage 1)

### Улучшения в архитектуре:

1. **HTTP-клиент:** ✅
   - Поддержка 304 Not Modified (Conditional GET)
   - Exponential backoff + jitter уже реализованы
   - SSL fallback для сертификатов

2. **Graceful Degradation:** ✅
   - 403/429 → 10 минут cooldown
   - Источник временно отключается
   - Бот продолжает работу с остальными

3. **Оптимизация:** ✅
   - RSS со статусом 304 не парсируется
   - BeautifulSoup/feedparser в asyncio.to_thread (не блокируют event loop)
   - Semaphore (6 параллельных запросов)

4. **Архитектура БД:** ✅
   - Таблица rss_state для ETag/Last-Modified
   - DBWriter модуль для высоконагруженных систем (опционально)
   - asyncio.to_thread для express-операций

---

## 🔄 Процесс деплоя на Railway

### Вариант 1: Автоматический (РЕКОМЕНДУЕТСЯ)

Railway автоматически следит за GitHub `main` веткой:

1. Коммиты уже в main ✅ (`git push` выполнен)
2. Railway обнаружит изменения автоматически
3. Запустится CI/CD из `.github/workflows/deploy.yml`
4. Бот переразвернётся с новым кодом

### Вариант 2: Ручной триггер

```bash
# Если нужно принудительно запустить deployment
railway deploy
```

### Вариант 3: Через Railway CLI

```bash
# Установка Railway CLI
npm i -g @railway/cli

# Логин в Railway
railway login

# Деплой
railway up
```

---

## 📊 Ожидаемые результаты после деплоя

| Метрика | Ожидание |
|---------|---------|
| **Стабильность** | 24/7 без сбоев (благодаря graceful degradation) |
| **Сбор новостей** | Каждые 2 минуты ± 5% |
| **Трафик RSS** | ↓ 90% (благодаря 304 Not Modified) |
| **Event loop** | Не блокируется (asyncio.to_thread для парсинга) |
| **Источники** | Автоматический cooldown при блокировке |

---

## 🔍 Как проверить статус после деплоя

### 1. Railway Dashboard
- Перейти на https://railway.app
- Открыть проект TopNews
- Вкладка "Deployments" → последний деплой

### 2. Логи
```bash
railway logs -f
```

### 3. Telegram бот
- Отправить `/status` в бот-канал
- Ожидать ответа со статистикой

### 4. БД
```bash
# Проверить наличие новостей
sqlite3 db/news.db "SELECT COUNT(*) FROM published_news;"
```

---

## ⚠️ Важные замечания

### Безопасность ✅
- Токен Telegram не логируется
- Нет обхода антибот-защиты
- Graceful degradation при блокировке
- Соблюдены авторские права (заголовок + абзац)

### Производительность ✅
- Semaphore ограничивает нагрузку
- Cooldown для блокированных источников
- Async парсинг не блокирует event loop
- SQLite с WAL для параллельных операций

### Мониторинг 📊
Рекомендуется отслеживать:
- Время обработки одного сбора
- Количество 403/429 ошибок
- Длину очереди (если DBWriter используется)
- Размер БД

---

## 🆘 Troubleshooting

### Бот не запускается
```
Проверить:
1. TELEGRAM_TOKEN и TELEGRAM_CHANNEL_ID установлены?
2. requirements.txt все зависимости?
3. Логи: railway logs -f
```

### Новости не собираются
```
Проверить:
1. Источники доступны? (curl https://lenta.ru/rss/)
2. Нет ли 403/429 ошибок?
3. БД инициализирована? (init_db.py)
```

### "database is locked"
```
Решение:
1. Перезагрузить бот (railway restart)
2. Проверить WAL режим: PRAGMA journal_mode=WAL;
3. Увеличить busy_timeout в database.py
```

---

## 📚 Документация

- [RAILWAY_README.md](../RAILWAY_README.md) — полный гайд
- [REFACTORING_COMPLETE.md](../docs/REFACTORING_COMPLETE.md) — изменения Stage 1
- [COPILOT_REFACTORING_PROMPT.md](../docs/COPILOT_REFACTORING_PROMPT.md) — архитектурные требования

---

## ✨ Следующие этапы

После успешного деплоя:

1. **Stage 2:** Расширенный мониторинг и аналитика
2. **Stage 3:** Интеграция с другими источниками (Telegram каналы, YouTube)
3. **Stage 4:** Персонализация подписок по категориям

---

**Дата:** 01 февраля 2026  
**Статус:** ✅ Готово к production  
**Последний коммит:** 50e807d
