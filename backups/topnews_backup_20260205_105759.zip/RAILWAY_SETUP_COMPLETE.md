# ✅ TopNews Bot - Railway Deployment Setup Complete

## 🎉 Что было подготовлено

Ваш проект **TopNews Bot** полностью готов к развертыванию на Railway!

---

## 📦 Новые файлы (9 файлов)

### Конфигурация для Railway:
- **`Procfile`** - Entry point для Railway (запуск бота)
- **`railway.json`** - Конфигурация Railway (restart policy, volumes)
- **`config/railway_config.py`** - Поддержка переменных окружения Railway

### Инициализация:
- **`init_db.py`** - Инициализация БД при запуске на Railway

### Документация:
- **`RAILWAY_README.md`** - Полный гайд по Railway (основной документ)
- **`RAILWAY_QUICKSTART.md`** - Быстрый старт за 10 минут
- **`RAILWAY_DEPLOY.md`** - Подробная документация по развертыванию

### Проверка:
- **`check_railway_ready.py`** - Проверка готовности проекта к деплою

### CI/CD:
- **`.github/workflows/deploy.yml`** - GitHub Actions для автоматического развертывания

### Скрипты публикации:
- **`push_to_github.sh`** - Linux/Mac скрипт для публикации
- **`push_to_github.bat`** - Windows скрипт для публикации

---

## 🔄 Обновленные файлы

- **`main.py`** - Теперь поддерживает Railway конфигурацию
  - Автоматически подхватывает переменные из Railway
  - Fallback на локальную .env конфигурацию

---

## 🚀 Быстрый старт (5 минут)

### Шаг 1: Проверка готовности

```bash
python check_railway_ready.py
```

Должны увидеть: `✅ ВСЕ ПРОВЕРКИ ПРОЙДЕНЫ!`

### Шаг 2: Создать Telegram бота

1. Откройте Telegram
2. Найдите **@BotFather**
3. Отправьте `/newbot`
4. Следуйте инструкциям
5. Скопируйте **TELEGRAM_TOKEN**

### Шаг 3: Создать Telegram канал

1. В Telegram создайте новый **приватный** канал
2. Добавьте **вашего бота** как администратора
3. Добавьте **@userinfobot** в канал
4. Напишите `/info`
5. Скопируйте **Chat ID** (отрицательное число)

### Шаг 4: Публикация в GitHub

```bash
# Windows:
push_to_github.bat

# Linux/Mac:
bash push_to_github.sh
```

### Шаг 5: Развертывание на Railway

1. Перейдите на https://railway.app
2. Нажмите **"New Project"**
3. Выберите **"Deploy from GitHub"**
4. Выберите репозиторий **jfsagro-glitch/topnews**
5. В **Variables** установите:
   ```env
   TELEGRAM_TOKEN=ваш_токен
   TELEGRAM_CHANNEL_ID=ваш_channel_id
   ```
6. Нажмите **Deploy**

✅ **Готово! Бот запустится автоматически**

---

## 📋 Переменные окружения Railway

### Обязательные:

```env
TELEGRAM_TOKEN=123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11
TELEGRAM_CHANNEL_ID=-1001234567890
```

### Рекомендуемые:

```env
CHECK_INTERVAL_SECONDS=120
LOG_LEVEL=INFO
```

### Дополнительные:

```env
DATABASE_PATH=/persist/news.db  # Для сохранения БД
USE_PROXY=False
PROXY_URL=http://proxy:8080
CLOSED_SOURCE_LOGIN=username
CLOSED_SOURCE_PASSWORD=password
```

---

## 💾 Сохранение БД (важно!)

По умолчанию БД теряется при перезагрузке.

### Включить persistence:

1. Railway Dashboard → **Volumes**
2. Добавьте volume: `/persist`
3. В **Variables** установите: `DATABASE_PATH=/persist/news.db`

Теперь БД будет сохраняться между перезагрузками.

---

## 🔍 Проверка статуса

### В Railway Dashboard:

1. Перейдите в **Deployments**
2. Посмотрите **Logs**
3. Должны увидеть:

```
✅ Bot started successfully
✅ Database ready
✅ Periodic collection started
```

### В Telegram:

1. Напишите боту `/help`
2. Должны увидеть список команд
3. Отправьте `/status` - должна быть информация

---

## 📊 Архитектура для Railway

```
┌─────────────────────────────────┐
│   Railway Container             │
├─────────────────────────────────┤
│  Procfile → python main.py      │
│           ↓                     │
│  main.py                        │
│  ├─ Загружает railway_config.py │
│  ├─ Инициализирует БД           │
│  └─ Запускает NewsBot           │
│           ↓                     │
│  NewsBot (async loop)           │
│  ├─ collect_and_publish()       │
│  ├─ run_periodic_collection()   │
│  └─ Обработка команд            │
│           ↓                     │
│  SourceCollector (asyncio)      │
│  ├─ RSSParser                   │
│  ├─ HTMLParser                  │
│  └─ TelegramSource              │
│           ↓                     │
│  NewsDatabase (/persist)        │
│           ↓                     │
│  Telegram API                   │
└─────────────────────────────────┘
```

---

## 🆘 Troubleshooting

### ❌ Ошибка: "ModuleNotFoundError"
**Решение:** Railway должен установить зависимости из `requirements.txt`
- Проверьте что файл в корне репозитория
- Пересоздайте deployment

### ❌ Бот не публикует новости
**Проверьте:**
1. TELEGRAM_TOKEN и TELEGRAM_CHANNEL_ID в Variables
2. Логи на предмет ошибок (Railway Dashboard → Logs)
3. Бот добавлен в канал администратором

### ❌ БД потеряется при перезагрузке
**Решение:** Добавьте Volume (/persist) в Railway

### ❌ Медленный сбор новостей
**Увеличьте интервал:**
```env
CHECK_INTERVAL_SECONDS=180  # 3 минуты вместо 2
TIMEOUT_SECONDS=60         # 60 сек вместо 30
```

---

## 📚 Документация

Полная документация доступна:

- **[RAILWAY_README.md](RAILWAY_README.md)** - Основной гайд (начните отсюда!)
- **[RAILWAY_QUICKSTART.md](RAILWAY_QUICKSTART.md)** - Быстрый старт за 10 минут
- **[RAILWAY_DEPLOY.md](RAILWAY_DEPLOY.md)** - Подробная документация
- **[ARCHITECTURE.md](ARCHITECTURE.md)** - Архитектура проекта
- **[README.md](README.md)** - Основной README
- **[SETUP.md](SETUP.md)** - Локальная установка

---

## 🔄 Автоматические обновления

После первоначального развертывания:

```bash
# 1. Делайте изменения локально
# 2. Пушьте в GitHub
git add .
git commit -m "Update sources"
git push origin main

# 3. Railway автоматически обновит (1-2 мин)
# 4. Бот перезагрузится с новым кодом
```

---

## 💰 Стоимость Railway

- **$5 кредит в месяц** (free tier)
- Для простого бота этого достаточно
- Средний расход: **$1-3 в месяц**

---

## ✅ Чек-лист

- [ ] Выполнена проверка `python check_railway_ready.py`
- [ ] Создан Telegram бот (@BotFather)
- [ ] Получен TELEGRAM_TOKEN
- [ ] Создан приватный Telegram канал
- [ ] Получен TELEGRAM_CHANNEL_ID
- [ ] Код запушен в GitHub
- [ ] Создан проект на Railway.app
- [ ] Установлены переменные окружения
- [ ] Deployment в статусе "Success"
- [ ] Бот отвечает на /help
- [ ] Новости появляются в канале
- [ ] Добавлен Volume для persistence БД

---

## 📞 Полезные ссылки

- **Railway:** https://railway.app
- **Railway Docs:** https://docs.railway.app
- **Railway Discord:** https://railway.app/discord
- **GitHub Repository:** https://github.com/jfsagro-glitch/topnews
- **Telegram Bot API:** https://core.telegram.org/bots
- **@BotFather:** https://t.me/BotFather

---

## 🎉 Готово!

Ваш **TopNews Bot** полностью подготовлен к развертыванию на Railway!

**Следующий шаг:** Запустите `check_railway_ready.py` или `push_to_github.bat`

```bash
python check_railway_ready.py
```

или

```bash
push_to_github.bat
```

---

**Успехов! 🚀**
