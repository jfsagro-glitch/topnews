# 🔴 DeepSeek API 400 Bad Request - Diagnostic Report

## Проблема
Все запросы к DeepSeek API возвращают **HTTP 400 Bad Request**:
```
2026-02-03T09:21:37 - httpx - INFO - HTTP Request: POST https://api.deepseek.com/v1/chat/completions "HTTP/1.1 400 Bad Request"
2026-02-03T09:21:37 - net.deepseek_client - WARNING - DeepSeek text extraction API error: status=400
```

Результат: **"ИИ не доступен для пересказа"** (AI summarization unavailable)

---

## 🔍 Корневая Причина
**`DEEPSEEK_API_KEY` environment variable is NOT set in Railway deployment**

Когда бот работает в Railway:
1. `DEEPSEEK_API_KEY` не определена → пустая строка
2. API ключ пуст → `Authorization: Bearer ` (без ключа)
3. DeepSeek отклоняет запрос с 400 ошибкой

---

## ✅ Решение: Добавить API Ключ в Railway

### Шаг 1: Получить DeepSeek API Key
1. Перейди на https://platform.deepseek.com
2. Войди в аккаунт (или создай новый)
3. Перейди в **API Keys** / **Ключи API**
4. Нажми **Create New Key** / **Создать новый ключ**
5. Скопируй ключ (начинается с `sk-`)

### Шаг 2: Добавить в Railway
1. Открой Railway Dashboard → Твой проект TopNews
2. Перейди в **Variables** / **Переменные**
3. Добавь новую переменную:
   - **Name**: `DEEPSEEK_API_KEY`
   - **Value**: `sk-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx`
   - (вставь свой ключ)
4. Нажми **Save**
5. Railway автоматически перезапустит контейнер

### Шаг 3: Проверить
1. Подожди 1-2 минуты для перезагрузки
2. Попробуй запросить пересказ новости в Telegram боте
3. Должно работать!

---

## 🧪 Локальное Тестирование (опционально)

Если хочешь проверить на локальной машине:

```bash
# 1. Установи переменную окружения
export DEEPSEEK_API_KEY="sk-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"

# 2. Запусти тест
python test_deepseek_api.py
```

Должен показать:
```
✓ API Key status:
  - Exists: True
  - Length: 48
  - Starts with: sk-...

✓ Testing API endpoint: https://api.deepseek.com/v1/chat/completions
✓ Response status: 200
✅ API is working!
```

---

## 📊 Диагностика в Логах

После добавления ключа в Railway, логи будут показывать:

**❌ ПЕРЕД (с ошибкой):**
```
2026-02-03 09:21:37 - net.deepseek_client - WARNING - DeepSeek API error: status=400, response="error"...
```

**✅ ПОСЛЕ (работает):**
```
2026-02-03 09:22:00 - bot - INFO - Published: Раскрыты детали ночного ответного удара...
```

---

## 🔧 Дополнительные Проверки

Если после добавления ключа ошибки продолжаются:

### Проверка 1: Ключ скопирован правильно?
- Убедись, что нет пробелов в начале/конце
- Ключ должен начинаться с `sk-`
- Длина должна быть ~48 символов

### Проверка 2: Railway перезагрузился?
- Перейди в **Deployments** в Railway
- Должно быть новое развёртывание после добавления переменной
- Если нет → нажми **Redeploy** вручную

### Проверка 3: Баланс в DeepSeek?
- Проверь на https://platform.deepseek.com/account/balance
- API ключ может быть неактивным из-за отсутствия баланса
- Добавь средства если нужно

---

## 📋 Итоговый Чеклист

- [ ] Получил API ключ с deepseek.com
- [ ] Добавил `DEEPSEEK_API_KEY` в Railway Variables
- [ ] Railway перезагрузился (новое deployment)
- [ ] Протестировал пересказ в Telegram боте
- [ ] AI пересказ работает
- [ ] Логи показывают успешные ответы от DeepSeek

---

## ❓ Вопросы?

Если всё ещё не работает:
1. Проверь Railway логи (вкладка **Logs**)
2. Ищи сообщения с `DeepSeek API key not configured`
3. Убедись что переменная появилась в **Variables**
