# PROMPT ДЛЯ GITHUB COPILOT / CURSOR

## Задача: Добавить кнопку AI Summarize с DeepSeek API

### Контекст

Telegram-бот TopNews публикует новости 3 раза в день с кнопкой **"ИИ"** для пересказа, которая будет:

1. При нажатии вызывать DeepSeek API
2. Получить пересказ новости ИИ
3. Показать результат в новом сообщении с исходным источником

### Требования

#### 1. UI/UX

**Требуется:**
```
[ИИ]
```

- Одна кнопка (InlineKeyboardMarkup с 1 кнопкой)
- При клике на "ИИ" → загрузка → пересказ в сообщении
- Исходные новости не удаляются, пересказ отправляется отдельно

#### 2. Backend (DeepSeek API)

**API Endpoint:**
```
https://api.deepseek.com/chat/completions
```

**Параметры:**
- Model: `deepseek-chat`
- API Key: `${DEEPSEEK_API_KEY}` (из .env)
- Max tokens: 500 (для компактного пересказа)
- Temperature: 0.7 (балансировка между точностью и креативностью)

**Промт для пересказа:**
```
Ты - редактор новостей. Дай краткий, информативный пересказ этой новости (200-300 слов). 
Сохрани все ключевые факты, но переформулируй так, чтобы было понятно новичку.

Исходная новость:
---
{title}

{text}
---

Напиши пересказ без вводных фраз типа "Согласно новости", просто текст.
Добавь в конец строку: "Источник: {source}"
```

#### 3. Обработка ошибок

- Если DeepSeek недоступен → показать уведомление "API недоступен"
- Если новость слишком короткая → пропустить запрос
- Timeout: 10 секунд на запрос

#### 4. Rate Limiting

- Максимум 3 запроса в минуту на одного пользователя
- Кэширование результата на 1 час (DB таблица `ai_summaries`)

#### 5. Юридическая безопасность

✅ **РАЗРЕШЕНО:**
- Использование DeepSeek API для трансформации контента (пересказ)
- Указание исходного источника
- Пересказ собственного контента (мы имеем лицензию через RSS/HTML)
- Сохранение лога для аудита

❌ **ЗАПРЕЩЕНО:**
- Удалять исходный контент или скрывать источник
- Не указывать DeepSeek как источник пересказа
- Использовать результат для переепубликации

#### 6. Логирование

```python
logger.info(f"AI Summarize requested for news_id={news_id}, user={user_id}")
logger.info(f"DeepSeek API response: {response_time}ms, tokens={tokens_used}")
logger.warning(f"AI Summarize failed: {error}, news_id={news_id}")
```

### Файлы для изменения

1. **bot.py:**
    - Добавить кнопку "ИИ" в `_format_news_message()`
    - Обработчик callback'а `on_ai_summarize_button_pressed()`
   - Функция `_summarize_with_deepseek()`
   - Rate limiting (dict с timestamps)

2. **db/database.py:**
   - Новая таблица `ai_summaries` (id, news_id, summary_text, created_at)
   - Методы `get_cached_summary()` и `save_summary()`

3. **config/config.py:**
   - `DEEPSEEK_API_KEY` (из .env)
   - `DEEPSEEK_API_ENDPOINT = "https://api.deepseek.com/chat/completions"`
   - `AI_SUMMARY_TIMEOUT = 10`
   - `AI_SUMMARY_MAX_REQUESTS_PER_MINUTE = 3`

4. **requirements.txt:**
   - Проверить наличие `httpx` (уже есть для HTTP запросов)

### Примеры использования

**Текущий workflow:**
```
Пользователь видит новость в канале:
┌─────────────────────────────────────┐
│ Заголовок новости                   │
│                                     │
│ Первый абзац новости...             │
│                                     │
│ Источник: Lenta.ru                  │
│ https://lenta.ru/news/2026/01/01... │
│                                     │
│ #Россия                             │
│                                     │
│ [ИИ]                                │
└─────────────────────────────────────┘

Нажимает [ИИ] → в ЛС приходит:

┌─────────────────────────────────────┐
│ 🤖 Пересказ: Заголовок новости     │
│                                     │
│ [Пересказ ИИ 200 слов...]           │
│                                     │
│ Источник: Lenta.ru                  │
│ 🔗 Исходная: https://lenta.ru/...   │
│                                     │
│ ⏱️ Пересказано в 2.3 сек            │
└─────────────────────────────────────┘
```

### Код-структура

**Структура в bot.py:**
```python
class NewsBot:
    def __init__(self):
        # ... существующий код
        self.ai_rate_limit = {}  # {user_id: [timestamp1, timestamp2, ...]}
        self.deepseek_client = AsyncDeepSeekClient()
    
    async def _create_news_keyboard(self, news_id):
        """Создать кнопку ИИ"""
        return InlineKeyboardMarkup([
            [
                InlineKeyboardButton("ИИ", callback_data=f"ai_{news_id}")
            ]
        ])
    
    async def on_ai_summarize_button(self, update, context):
        """Обработчик нажатия кнопки AI"""
        news_id = extract_news_id(update.callback_query.data)
        user_id = update.effective_user.id
        
        # Rate limiting
        if self._check_rate_limit(user_id):
            await update.callback_query.answer("⏱️ Слишком частые запросы. Подождите...")
            return
        
        # Загрузка
        await update.callback_query.answer("⏳ Создаю пересказ...")
        
        # Получить новость
        news = self.db.get_news_by_id(news_id)
        
        # Проверить кэш
        cached = self.db.get_cached_summary(news_id)
        if cached:
            summary = cached
        else:
            # Вызвать DeepSeek
            summary = await self.deepseek_client.summarize(
                title=news['title'],
                text=news['text']
            )
            # Кэшировать
            self.db.save_summary(news_id, summary)
        
        # Отправить результат
        await context.bot.send_message(
            chat_id=user_id,
            text=f"🤖 Пересказ: {news['title']}\n\n{summary}\n\nИсточник: {news['source']}",
            disable_web_page_preview=True
        )
```

### Примечания

- **DeepSeek выбран потому что:** дешевле Claude/GPT-4, хороший качество, простой API
- **Rate limiting:** защита от спама и для экономии (берём деньги за токены)
- **Кэширование:** одна и та же новость не пересказывается дважды
- **Таймаут:** 10 сек достаточно для DeepSeek (обычно 2-3 сек)

### Доп. замечания

1. **Юридическое подтверждение:** пересказ ИИ не нарушает авторские права (это трансформация, а не копирование)
2. **Исходный источник:** всегда указываем ссылку на исходную новость
3. **Прозрачность:** пользователь видит, что это AI Summarize, не скрыто
4. **Контроль качества:** первые несколько пересказов вручную проверить

---

**Дата:** 01 февраля 2026  
**Уровень сложности:** Medium (REST API + Telegram callbacks + DB)  
**Время реализации:** 2-3 часа
